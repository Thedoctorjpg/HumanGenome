# Genome GC Content & 3-Base Periodicity Analysis

This Python script analyzes a genome FASTA file to detect coding regions by measuring GC content and 3-base periodicity in sliding windows.

## How It Works
- Converts DNA sequences into GC/AT binary signals
- Performs FFT to extract the periodic signal strength at 3-base intervals
- Plots GC% vs periodicity with AT% as a color gradient

## Usage

1. Install dependencies:

```
pip install -r requirements.txt
```

2. Place your genome FASTA file in the directory and name it `genome.fa`.

3. Run the script:

```
python analysis.py
```

## Output

- A scatter plot showing GC% vs 3-base periodicity
- AT% visualized as a color gradient

## Requirements

- Python 3
- Biopython
- NumPy
- SciPy
- Matplotlib

Tested on T2T-CHM13 and other reference genome builds.
