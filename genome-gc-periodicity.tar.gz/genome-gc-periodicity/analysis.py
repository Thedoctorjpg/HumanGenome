import numpy as np
from Bio import SeqIO
from scipy.fftpack import fft
import matplotlib.pyplot as plt

# Convert DNA sequence to binary vector: 1 for G/C, 0 for A/T
def one_hot_gc(seq):
    return np.array([1 if b in 'GCgc' else 0 for b in seq], dtype=float)

# Calculate normalized power at frequency corresponding to 3-base periodicity
def periodicity_score(arr):
    N = len(arr)
    fft_vals = np.abs(fft(arr))
    k = N // 3  # Target frequency for 3-base periodicity
    return fft_vals[k] / np.sum(fft_vals)  # Normalized strength of that frequency

# Parameters
window = 300     # Size of each window
step = 100       # Step between windows

# Load genome sequence from FASTA file
seq = SeqIO.read("genome.fa", "fasta").seq

# Lists to hold GC content, AT content, and periodicity scores
scores, gc_perc, at_perc = [], [], []

# Slide window across genome sequence
for i in range(0, len(seq) - window + 1, step):
    fragment = seq[i:i + window]
    arr = one_hot_gc(fragment)
    scores.append(periodicity_score(arr))
    gc_perc.append(100 * arr.sum() / window)                   # % GC content
    at_perc.append(100 * (window - arr.sum()) / window)        # % AT content

# Plotting GC% vs 3-base periodicity, with AT% as color
plt.figure(figsize=(10, 6))
scatter = plt.scatter(gc_perc, scores, c=at_perc, cmap='viridis', s=10)
plt.xlabel('GC%')
plt.ylabel('3-base Periodicity Score')
plt.title('GC Content vs 3-Base Periodicity\n(Coding Signal Detection)')
plt.colorbar(scatter, label='AT%')
plt.grid(True)
plt.tight_layout()
plt.show()
